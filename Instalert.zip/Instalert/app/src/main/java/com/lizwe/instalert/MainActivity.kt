package com.lizwe.instalert

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val crimeCard = findViewById<CardView>(R.id.card_crime)
        val serviceCard = findViewById<CardView>(R.id.card_service)
        val accidentCard = findViewById<CardView>(R.id.card_accident)

        crimeCard.setOnClickListener{
            val intent = Intent(this, CrimeActivity::class.java)
            startActivity(intent)
    }
        serviceCard.setOnClickListener{
            val intent = Intent(this,ServiceActivity::class.java)
            startActivity(intent)
        }
        accidentCard.setOnClickListener{
            val intent = Intent(this,AccidentActivity::class.java)
            startActivity(intent)
        }
    }
}